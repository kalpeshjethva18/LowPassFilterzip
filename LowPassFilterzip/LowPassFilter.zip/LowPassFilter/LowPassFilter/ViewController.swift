//
//  ViewController.swift
//  LowPassFilter
//
//  Created by macpc on 05/04/16.
//  Copyright (c) 2016 macpc. All rights reserved.
//

import UIKit
import CoreMotion
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate, UIScrollViewDelegate  {
    
    var motionManager = CMMotionManager()
    var counter = NSInteger()
    @IBOutlet var lblstepcounter: UILabel!
    
    var xincrease = Bool()
    var yincrease = Bool()
    var xdecrease =  Bool()
    var ydecrease = Bool()
    
    
    var tempWidth = NSInteger()
    var tempHeight = NSInteger()
    var ScreenView = UIView()
    

    
    
    var lastdirection = NSString()
    var FirstPosition = Bool()
    var isnull = Bool()
    var myview = UIView();
    
    var degreearray = NSMutableArray();
    var dictdegree = NSMutableDictionary()
    var NewSpacecounter = NSInteger();
    
    var StartX = NSInteger()
    var StartY = NSInteger()
    
    var lastX = NSInteger()
    var lastY = NSInteger()
    
    var tempsizeX = NSInteger()
    var tempsizeY = NSInteger()
    
    
    var MainScrollView = UIScrollView()
    var canvasview = UIView();
    
    
    
    var locationManager:CLLocationManager!
    var latitudeOfTargetedPoint: CLLocationDegrees?
    var longitudeOfTargetedPoint: CLLocationDegrees?
    var targetLocation: CLLocation?
    
    @IBOutlet var lblcounter: UILabel!
    @IBOutlet var lbldirection: UILabel!
    @IBOutlet weak var stateImageView: UIImageView!
    let activityManager = CMMotionActivityManager()
    
    
    
    @IBOutlet var pathscroll: UIScrollView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        isnull = true;
        
        var ypostion = NSInteger(self.view.frame.size.height/2)
        var xposition = NSInteger(self.view.frame.size.width/2)
        
        MainScrollView.frame = CGRectMake(0, 45, 320, 480)
        MainScrollView.showsHorizontalScrollIndicator = true
        MainScrollView.showsVerticalScrollIndicator = true
        canvasview.frame = CGRectMake(0, 0, 320, 480)
        self.view.addSubview(MainScrollView)
        
        StartX = xposition
        StartY = ypostion
        
        NewSpacecounter = 5;
        FirstPosition = false
        
        degreearray = ["N","NE","E","SE","S","SW","W","NW"]
        self.locationManager = CLLocationManager()
        
        if CLLocationManager.locationServicesEnabled() {
            self.locationManager.delegate = self
            self.locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
            self.locationManager.distanceFilter = 10
        }
        self.view.backgroundColor = UIColor.whiteColor()
        locationManager.startUpdatingHeading()
        latitudeOfTargetedPoint = CLLocationDegrees(48.557257)
        longitudeOfTargetedPoint = CLLocationDegrees(2.968518)
        
        
        
        
        motionManager.deviceMotionUpdateInterval = 0.1
        motionManager.startDeviceMotionUpdatesToQueue(NSOperationQueue.currentQueue(), withHandler:{
            deviceManager, error in
            var accelerationThreshold:Double = 0.3;
            var userAcceleration:CMAcceleration = self.motionManager.deviceMotion.userAcceleration//deviceManager.userAcceleration;
            if(fabs(userAcceleration.x) > accelerationThreshold) || (fabs(userAcceleration.y) > accelerationThreshold) || (fabs(userAcceleration.z) > accelerationThreshold)
            {
                self.counter++
                self.lblstepcounter.text = String(self.counter)
                
                /// dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), {
                
                if(self.isnull == false)
                {
                    if(self.FirstPosition == false)
                    {
                        var derection:NSInteger = self.degreearray.indexOfObject(self.lbldirection.text!)
                        var Directions = NSMutableArray()
                        Directions = ["North","East","East1","East2","south","west","west1","west2"]
                        var newindex = NSInteger()
                        for var i = 0; i < self.degreearray.count; i++
                        {
                            var index = derection + i
                            if(index > 7)
                            {
                                index = newindex;
                                newindex++;
                            }
                            self.dictdegree.setValue(self.degreearray.objectAtIndex(index), forKey: Directions.objectAtIndex(i) as NSString)
                        }
                        self.FirstPosition = true;
                    }
                    var foundationDictionary:NSDictionary = NSDictionary(dictionary: self.dictdegree)
                    let keys:NSArray = foundationDictionary.allKeysForObject(self.lbldirection.text!) as NSArray
                    var directionString:String = keys.objectAtIndex(0) as String
                    
                    if self.lastdirection != directionString
                    {
                        if directionString == "North"
                        {
                            self.xincrease = false
                            self.yincrease = false
                            self.xdecrease = false
                            self.ydecrease = true
                        }
                        else if directionString == "south"
                        {
                            self.xincrease = false
                            self.yincrease = true
                            self.xdecrease = false
                            self.ydecrease = false
                        }
                        else if directionString == "west" || directionString == "west1" || directionString == "west2"
                        {
                            if self.yincrease == true
                            {
                                self.StartY = self.StartY + 5
                            }
                            self.xincrease = false
                            self.yincrease = false
                            self.xdecrease = true
                            self.ydecrease = false
                        }
                        else
                        {
                            if self.yincrease == true
                            {
                                self.StartY = self.StartY + 5
                            }
                            self.xincrease = true
                            self.yincrease = false
                            self.xdecrease = false
                            self.ydecrease = false
                        }
                        self.lastdirection = directionString
                    }
                    self.sayHello(directionString)
                }
            }
        })
    }
    func sayHello(directionString: String) -> Void
    {
        var path: UIBezierPath = UIBezierPath()
        if directionString == "North"
        {
            StartY = StartY - 10
//            path.moveToPoint(CGPoint(x: StartX, y: StartY))
//            path.addLineToPoint(CGPoint(x: StartX, y: StartY + NewSpacecounter))
            if lastY > StartY
            {
                if StartY < 0
                {
                    lastY = StartY
                }
            }
            xincrease = false
            yincrease = false
            xdecrease = false
            ydecrease = true
        }
        else if directionString == "south" {
            
            StartY = StartY + 10
            xincrease = false
            yincrease = true
            xdecrease = false
            ydecrease = false
//            path.moveToPoint(CGPoint(x: StartX, y: StartY))
//            path.addLineToPoint(CGPoint(x: StartX, y: StartY + NewSpacecounter))
        }
        else if directionString == "west" || directionString == "west1" || directionString == "west2"{
            StartX = StartX - 10
            
            if lastX > StartX
            {
                if StartX < 0
                {
                    lastX = StartX
                }
            }
            xincrease = false
            yincrease = false
            xdecrease = true
            ydecrease = false
//            path.moveToPoint(CGPoint(x: StartX, y: self.StartY))
//            path.addLineToPoint(CGPoint(x: StartX + NewSpacecounter, y: self.StartY))
        }
        else
        {
            StartX = StartX + 10
            
            xincrease = true
            yincrease = false
            xdecrease = false
            ydecrease = false
            
            
//            path.moveToPoint(CGPoint(x: StartX, y: self.StartY))
//            path.addLineToPoint(CGPoint(x: StartX - NewSpacecounter, y: self.StartY))
        }
        var lmyview = UIView()
        lmyview.frame = CGRectMake(CGFloat(StartX), CGFloat(StartY), 5, 5)
        if StartX>320
        {
            lmyview.backgroundColor = UIColor.greenColor()
        }
        else
        {
            lmyview.backgroundColor = UIColor.redColor()
        }
        self.pathscroll.delegate = self
        self.pathscroll.backgroundColor = UIColor.clearColor()
        
        
        if StartX < 0 && ydecrease != true
        {
            if(xincrease == true)
            {
                self.pathscroll.setContentOffset(CGPointMake(CGFloat(lastX), CGFloat(lastY)), animated: false)
            }
            else
            {
                if (lastX == 0)
                {
                    canvasview.frame = CGRectMake(CGFloat(0 - StartX), CGFloat(lastY),CGFloat(320 - StartX), 480)
                }
                else{
                    canvasview.frame = CGRectMake(CGFloat(0 - lastX), CGFloat(0 - lastY),CGFloat(320 - StartX), 480)
                }
                self.pathscroll.setContentOffset(CGPointMake(CGFloat(StartX - 10), CGFloat(lastY)), animated: false)
            }
        }
        else if ydecrease == true && StartY < 0
        {
            self.pathscroll.setContentOffset(CGPointMake(CGFloat(lastX), CGFloat(StartY)), animated: false)
        }
        else
        {
            self.pathscroll.setContentOffset(CGPointMake(CGFloat(lastX), CGFloat(lastY)), animated: false)
        }
        
        
        if StartX > 320 && xincrease == true
        {
            tempsizeX = tempsizeX + 20
        }
        else if StartY > 480 && yincrease == true
        {
            tempsizeY = tempsizeY + 20
        }
        else if StartX < 0 && xdecrease == true
        {
            if lastX == 0
            {
                tempsizeX = tempsizeX - (StartX) + 20
            }
            else
            {
                tempsizeX = tempsizeX - (lastX) + 20
            }
        }
        else if StartY < 0 && ydecrease == true
        {
            if lastY == 0
            {
                tempsizeY = tempsizeY - (StartY) + 20
            }
            else
            {
                tempsizeY = tempsizeY - (lastY) + 20
            }
        }
        
        if StartX > 320
        {
            self.MainScrollView.setContentOffset(CGPointMake(CGFloat(StartX), CGFloat(0)), animated: false)
        }
        
        if StartX > 320
        {
            tempWidth = StartX - lastX
        }
        if StartY > 480
        {
            tempHeight = StartY - lastY
        }
        
        println("tempsizeX  \(tempsizeX) tempsizeY \(tempsizeY)")
        
        canvasview.backgroundColor = UIColor.yellowColor()
        canvasview.addSubview(lmyview)
        self.pathscroll.addSubview(canvasview)
        MainScrollView.addSubview(pathscroll)
        MainScrollView.contentSize = CGSizeMake(CGFloat(320 + tempsizeX), CGFloat(480 + tempsizeY))
        self.view.addSubview(MainScrollView)
    }
    func locationManager(manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        
        var degrees: Float = Float(newHeading.magneticHeading)
        if degrees >= 337.5 || degrees < 22.5 {
            lbldirection.text = "N"
        }
        else if degrees >= 22.5 && degrees < 67.5 {
            lbldirection.text = "NE"
        }
        else if degrees >= 67.5 && degrees < 112.5 {
            lbldirection.text = "E"
        }
        else if degrees >= 112.5 && degrees < 157.5 {
            lbldirection.text = "SE"
        }
        else if degrees >= 157.5 && degrees < 202.5 {
            lbldirection.text = "S"
        }
        else if degrees >= 202.5 && degrees < 247.5 {
            lbldirection.text = "SW"
        }
        else if degrees >= 247.5 && degrees < 292.5 {
            lbldirection.text = "W"
        }
        else if degrees >= 292.5 && degrees < 337.5 {
            lbldirection.text = "NW"
        }
        isnull = false;
    }
    @IBAction func clearuiview(sender: UIButton) {
        
        var ypostion = NSInteger(self.view.frame.size.height/2)
        var xposition = NSInteger(self.view.frame.size.width/2)
        
        StartX = xposition
        StartY = ypostion
        self.isnull = false
        self.FirstPosition = false
        myview.layer.sublayers.removeAll(keepCapacity: true)
    }
    @IBAction func screenShot(sender: UIButton) {
        screenShotMethod()
    }
    func screenShotMethod() {
        
        var widthh = tempsizeX + 320
        var heightt = tempsizeY + 480
        
        if tempHeight == 0
        {
            tempHeight = 670
        }
        if tempWidth == 0
        {
            tempWidth = 375
        }
        MainScrollView.frame = CGRectMake(0, 45, CGFloat(tempWidth), CGFloat(tempHeight))
        self.view.addSubview(MainScrollView)
        ScreenView.frame = CGRectMake(0, 0, CGFloat(tempWidth), CGFloat(tempHeight))
        UIGraphicsBeginImageContext(ScreenView.frame.size)
        view.layer.renderInContext(UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
    }
    @IBAction func ResetCounter(sender: UIButton) {
        counter = 0;
        self.lblstepcounter.text = "0"
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}